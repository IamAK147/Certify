<?php 
	$con = mysqli_connect("localhost","root","", "bcertify") or die("Couldn't connect to SQL server");
?>